import { z } from 'zod';

export const userSchema = z.object({
  username: z.string().min(1, 'Majburiy maydon').max(50),
  fullName: z.string().min(1, 'Majburiy maydon').max(150),
  role: z.enum(['ADMIN', 'ANTI_FRAUD', 'CREDIT_MANAGEMENT', 'LEGAL', 'UNDERWRITING', 'MANAGEMENT'], {
    required_error: 'Majburiy maydon',
  }),
  password: z.string().optional(),
  active: z.boolean(),
});

export type UserFormValues = z.infer<typeof userSchema>;

export function buildUserSchema(isCreate: boolean) {
  return userSchema.superRefine((data, ctx) => {
    if (isCreate && (!data.password || data.password.length < 6)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['password'],
        message: 'Parol kamida 6 ta belgidan iborat bo\'lishi kerak',
      });
    }
    if (!isCreate && data.password && data.password.length > 0 && data.password.length < 6) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['password'],
        message: 'Parol kamida 6 ta belgidan iborat bo\'lishi kerak',
      });
    }
  });
}
