import { useEffect, useMemo } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, Input, Modal, Select, Switch } from 'antd';
import type { UserResponse } from '@/shared/api/types';
import { roleLabels } from '@/shared/ui/strings';
import { handleFormError } from '@/shared/api/errorHandler';
import { useCreateUser } from './hooks/useCreateUser';
import { useUpdateUser } from './hooks/useUpdateUser';
import { buildUserSchema, type UserFormValues } from './schema';

interface UserFormModalProps {
  open: boolean;
  onClose: () => void;
  editingUser: UserResponse | null;
}

export function UserFormModal({ open, onClose, editingUser }: UserFormModalProps) {
  const isCreate = !editingUser;
  const createMutation = useCreateUser();
  const updateMutation = useUpdateUser();
  const schema = useMemo(() => buildUserSchema(isCreate), [isCreate]);

  const {
    control,
    handleSubmit,
    reset,
    setError,
    formState: { errors },
  } = useForm<UserFormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      username: '',
      fullName: '',
      role: 'ANTI_FRAUD',
      password: '',
      active: true,
    },
  });

  useEffect(() => {
    if (open) {
      reset(
        editingUser
          ? {
              username: editingUser.username,
              fullName: editingUser.fullName,
              role: editingUser.role,
              password: '',
              active: editingUser.active,
            }
          : {
              username: '',
              fullName: '',
              role: 'ANTI_FRAUD',
              password: '',
              active: true,
            },
      );
    }
  }, [open, editingUser, reset]);

  const isSubmitting = createMutation.isPending || updateMutation.isPending;

  const onSubmit = async (values: UserFormValues) => {
    try {
      if (editingUser) {
        await updateMutation.mutateAsync({
          id: editingUser.id,
          payload: {
            username: values.username,
            fullName: values.fullName,
            role: values.role,
            active: values.active,
            ...(values.password ? { password: values.password } : {}),
          },
        });
      } else {
        await createMutation.mutateAsync({
          username: values.username,
          fullName: values.fullName,
          role: values.role,
          password: values.password ?? '',
        });
      }
      onClose();
    } catch (error) {
      handleFormError(error, setError);
    }
  };

  return (
    <Modal
      title={editingUser ? 'Foydalanuvchini tahrirlash' : 'Yangi foydalanuvchi'}
      open={open}
      onCancel={onClose}
      onOk={handleSubmit(onSubmit)}
      confirmLoading={isSubmitting}
      okText="Saqlash"
      cancelText="Bekor qilish"
      destroyOnClose
    >
      <Form layout="vertical">
        <Form.Item
          label="Login"
          validateStatus={errors.username ? 'error' : ''}
          help={errors.username?.message}
        >
          <Controller name="username" control={control} render={({ field }) => <Input {...field} />} />
        </Form.Item>

        <Form.Item
          label="F.I.Sh."
          validateStatus={errors.fullName ? 'error' : ''}
          help={errors.fullName?.message}
        >
          <Controller name="fullName" control={control} render={({ field }) => <Input {...field} />} />
        </Form.Item>

        <Form.Item
          label="Rol"
          validateStatus={errors.role ? 'error' : ''}
          help={errors.role?.message}
        >
          <Controller
            name="role"
            control={control}
            render={({ field }) => (
              <Select
                {...field}
                options={Object.entries(roleLabels).map(([value, label]) => ({ value, label }))}
              />
            )}
          />
        </Form.Item>

        <Form.Item
          label={editingUser ? "Parol (o'zgartirmaslik uchun bo'sh qoldiring)" : 'Parol'}
          validateStatus={errors.password ? 'error' : ''}
          help={errors.password?.message}
        >
          <Controller
            name="password"
            control={control}
            render={({ field }) => <Input.Password {...field} autoComplete="new-password" />}
          />
        </Form.Item>

        {editingUser && (
          <Form.Item label="Faol">
            <Controller
              name="active"
              control={control}
              render={({ field }) => (
                <Switch checked={field.value} onChange={field.onChange} />
              )}
            />
          </Form.Item>
        )}
      </Form>
    </Modal>
  );
}
