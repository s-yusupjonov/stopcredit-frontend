/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_API_BASE_URL: string;
  readonly VITE_APP_NAME: string;
  readonly VITE_REVIEW_DEADLINE_DAYS: string;
  readonly VITE_MAX_UPLOAD_SIZE_MB: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
